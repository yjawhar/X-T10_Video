#!/bin/bash
for i in $(ls from)
do
    ffmpeg -i "from/$i" -vf scale=in_range=jpeg -vcodec prores -profile:v 1 -acodec copy "to/$i"
done
